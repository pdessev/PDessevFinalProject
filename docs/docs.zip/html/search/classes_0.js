var searchData=
[
  ['_5f_5fresult_0',['__Result',['../struct_____result.html',1,'']]]
];
