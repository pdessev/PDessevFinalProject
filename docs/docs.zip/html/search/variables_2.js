var searchData=
[
  ['centeralignmode_0',['CenterAlignMode',['../struct_gp_timer_config.html#a8c63d0e3f70b1fe9e2c2efcb22637ce4',1,'GpTimerConfig']]],
  ['clockdivision_1',['ClockDivision',['../struct_gp_timer_config.html#a9b0acca4af15f08fc812f7c350ef11d7',1,'GpTimerConfig']]]
];
