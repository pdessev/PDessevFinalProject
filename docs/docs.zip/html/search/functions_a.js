var searchData=
[
  ['timer_5fcalculate_5fautoreload_0',['timer_calculate_AutoReload',['../_timer___wrapper_8h.html#a67aae5ae9b28e910e581fe272436af06',1,'Timer_Wrapper.h']]],
  ['timer_5fcalculate_5fprescalar_1',['timer_calculate_prescalar',['../_timer___wrapper_8h.html#a96e7c91101209342eab15d78ce8db25b',1,'Timer_Wrapper.h']]],
  ['timer_5fstart_5ffrom_2',['timer_start_from',['../_timer___wrapper_8h.html#a6bebb5fb6f87c6e67ff25ebc2a9090b3',1,'Timer_Wrapper.h']]]
];
