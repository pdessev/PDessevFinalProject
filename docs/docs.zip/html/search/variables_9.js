var searchData=
[
  ['screentouched_0',['ScreenTouched',['../struct_app_state.html#ab93aab839a11ced63f306c249cbb4e0b',1,'AppState']]],
  ['screentouchedpos_1',['ScreenTouchedPos',['../struct_app_state.html#a87e064d8530f5bf53645a15f92c3e13e',1,'AppState']]]
];
