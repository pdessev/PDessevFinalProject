var searchData=
[
  ['appstate_0',['AppState',['../struct_app_state.html',1,'']]]
];
