var searchData=
[
  ['set_5fpending_5firq_0',['set_pending_IRQ',['../_interrupt_control_8h.html#a5ef958738d206971b85b889b8b6a5930',1,'InterruptControl.h']]],
  ['set_5ftimer_5fauto_5freload_1',['set_timer_auto_reload',['../_timer___wrapper_8h.html#a418b807efe03e8f7fadac959faeb6e2a',1,'Timer_Wrapper.h']]],
  ['set_5ftimer_5finterrupt_2',['set_timer_interrupt',['../_timer___wrapper_8h.html#af3de3319004d2a6d15e34a2fd0951dd7',1,'Timer_Wrapper.h']]],
  ['set_5ftimer_5ftime_3',['set_timer_time',['../_timer___wrapper_8h.html#adfec6da51390374f18ba005369fc4652',1,'Timer_Wrapper.h']]],
  ['start_5ftimer_4',['start_timer',['../_timer___wrapper_8h.html#a39bb6f2c137c2a4113c136498d150cc3',1,'Timer_Wrapper.h']]],
  ['stop_5ftimer_5',['stop_timer',['../_timer___wrapper_8h.html#a8c77fd724f7a348f97a58277fa14b8c9',1,'Timer_Wrapper.h']]]
];
