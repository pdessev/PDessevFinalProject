var searchData=
[
  ['autoreload_0',['AutoReload',['../struct_gp_timer_config.html#ae1500c15e8f47f1e83b7d20c3f8d4911',1,'GpTimerConfig']]],
  ['autoreloadbuffer_1',['AutoReloadBuffer',['../struct_gp_timer_config.html#a63359ddd77056854bcfdb048941f5f85',1,'GpTimerConfig']]]
];
