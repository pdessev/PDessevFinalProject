var searchData=
[
  ['gpiopinconfig_0',['GpioPinConfig',['../struct_gpio_pin_config.html',1,'']]],
  ['gptimerconfig_1',['GpTimerConfig',['../struct_gp_timer_config.html',1,'']]]
];
