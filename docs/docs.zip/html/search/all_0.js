var searchData=
[
  ['_5f_5fresult_0',['__Result',['../struct_____result.html',1,'__Result'],['../_error_handling_8h.html#aaefb56aa220c1b5a1c148ec03c1dd13a',1,'__Result:&#160;ErrorHandling.h']]]
];
