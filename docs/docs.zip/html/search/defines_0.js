var searchData=
[
  ['return_5for_5fignore_0',['RETURN_OR_IGNORE',['../_error_handling_8h.html#aa8cc25d6574086c6905c96741de11575',1,'ErrorHandling.h']]],
  ['return_5for_5fignore_5fclosure_1',['RETURN_OR_IGNORE_CLOSURE',['../_error_handling_8h.html#a6bda71ab1f8c59c0f52d7df4204aba58',1,'ErrorHandling.h']]]
];
