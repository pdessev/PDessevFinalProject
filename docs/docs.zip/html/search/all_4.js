var searchData=
[
  ['direction_0',['Direction',['../struct_gp_timer_config.html#aec728c5353d83461e2cb32bcc5537e1d',1,'GpTimerConfig']]],
  ['disable_5firq_1',['disable_IRQ',['../_interrupt_control_8h.html#a00070518af261cca8e394f06070203d6',1,'InterruptControl.h']]]
];
