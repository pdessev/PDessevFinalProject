var searchData=
[
  ['appstate_0',['AppState',['../_application_code_8h.html#a20ef834769d47c2d37c444681671b252',1,'ApplicationCode.h']]]
];
