var indexSectionsWithContent =
{
  0: "_abcdegilmnoprst",
  1: "_ag",
  2: "abegilmrst",
  3: "abcdegiprst",
  4: "abcdgioprst",
  5: "_abegiop",
  6: "begiop",
  7: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros"
};

